//
//  AddParseDetailsViewController.m
//  ParseSDKSample
//
//  Created by Stellent Software on 7/25/13.
//  Copyright (c) 2013 Stellent Software. All rights reserved.
//

#import "AddParseDetailsViewController.h"

@interface AddParseDetailsViewController ()

@end

@implementation AddParseDetailsViewController

@synthesize nameTextField;
@synthesize phoneNoTextField;
@synthesize emailIDTextField;
@synthesize profileImageView;
@synthesize saveButton;
@synthesize image;
@synthesize profileArray;
@synthesize updateButton;
@synthesize indexSelected;
@synthesize comingString;
@synthesize userInfo;
@synthesize delObjId;
@synthesize spinner;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        self.title=@"Parse API";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    profileArray=[[NSMutableArray alloc]init];
    
    self.spinner.hidesWhenStopped=YES;
    /*
    PFObject *userObject=[PFObject objectWithClassName:@"UserDetails"];
    
    [userObject deleteInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
        
        if (!succeeded)
        {
            if ([error code] == kPFErrorConnectionFailed )
            {
                NSLog(@"connection failure: %@", error);
            } else {
                NSLog(@"error when deleting: %@", error);
            }
            
        } else
        {
            // Delete the row
            //[self loadObjects];
            
             NSLog(@"%@", (succeeded ? @"YES" : @"NO"));
        }
    }];
*/
//    [userObject deleteInBackgroundWithBlock:^(BOOL succeeded, NSError *error)
//     {
//         NSLog(@"Error:%@",error);
//         NSLog(@"%@", (succeeded ? @"YES" : @"NO"));
//     }];
    
    float version = [[[UIDevice currentDevice] systemVersion] floatValue];
    NSLog(@"Current my iOS version is %0.2f",version);
    
    NSString *navBarImageName =  @"navBar.png" ;
    if (version>=5.00)
    {
        [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:navBarImageName] forBarMetrics:UIBarMetricsDefault];
        // [self.navigationController.navigationBar setBackgroundImage:nil forBarMetrics:UIBarMetricsDefault];
    }
	
	else {
        self.navigationController.navigationBar.layer.contents = (id)[UIImage imageNamed:navBarImageName].CGImage;
        
    }
	//-------Navigation bar image end
    
    
    //-------back button  start
	UIImage *myImage1 = [UIImage imageNamed:@"back_btn.png"];
	UIButton *myButton1 = [UIButton buttonWithType:UIButtonTypeCustom];
	[myButton1 setImage:myImage1 forState:UIControlStateNormal];
	myButton1.showsTouchWhenHighlighted = YES;
	myButton1.frame = CGRectMake(0.0, 3.0, 50,30);
	[myButton1 addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
	UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithCustomView:myButton1];
	self.navigationItem.leftBarButtonItem = leftButton;
    //-------back button  end
    UIImage *deleteImage = [UIImage imageNamed:@"delete_btn.png"];
	deleteButton = [UIButton buttonWithType:UIButtonTypeCustom];
	[deleteButton setImage:deleteImage forState:UIControlStateNormal];
	deleteButton.showsTouchWhenHighlighted = YES;
	deleteButton.frame = CGRectMake(0.0, 3.0, 50,30);
	[deleteButton addTarget:self action:@selector(delete:) forControlEvents:UIControlEventTouchUpInside];
	UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithCustomView:deleteButton];
	self.navigationItem.rightBarButtonItem = rightButton;
   
    
  
    
    
    /*
    PFFile *eventImage = [[userArray objectAtIndex:0] objectForKey:@"ProfileImageFile"];
    
    if(eventImage != NULL)
    {
        
        [eventImage getDataInBackgroundWithBlock:^(NSData *imageData, NSError *error) {
            
            UIImage *thumbnailImage = [UIImage imageWithData:imageData];
            UIImageView *thumbnailImageView = [[UIImageView alloc] initWithImage:thumbnailImage];
            
            self.profileImageView.image = thumbnailImageView.image;
            
        }];
     
     }
        */
    
    /*
    PFQuery *query = [PFQuery queryWithClassName:@"UserDetails"];
    [query getFirstObjectInBackgroundWithBlock:^(PFObject *userDetails, NSError *error)
    {
        // Do something with the returned PFObject in the gameScore variable.
        NSLog(@"Details%@", userDetails);
        
        NSLog(@"Name :%@",[userDetails objectForKey:@"UserName"]);
        NSLog(@"Phone No :%@",[userDetails objectForKey:@"UserPhoneNo"]);
        NSLog(@"Email ID :%@",[userDetails objectForKey:@"UserEmailID"]);
        NSLog(@"Image :%@",[userDetails objectForKey:@"ProfileImageFile"]);
    }];
     
     */
    
    
    if ([comingString isEqualToString:@"Update"])
    {
        self.saveButton.hidden=YES;
        self.navigationItem.rightBarButtonItem.enabled = YES;
        deleteButton.hidden=NO;
        
        [self.spinner startAnimating];
        
        PFQuery *query = [PFQuery queryWithClassName:@"UserDetails"];
        
        NSArray *userArray=[query findObjects];
        
        // Do something with the returned PFObject in the gameScore variable.
        NSLog(@"User Details%@", userArray);
        
        self.nameTextField.text=[[userArray objectAtIndex:indexSelected] objectForKey:@"UserName"];
        
        self.phoneNoTextField.text=[[userArray objectAtIndex:indexSelected] objectForKey:@"UserPhoneNo"];
        
        self.emailIDTextField.text=[[userArray objectAtIndex:indexSelected] objectForKey:@"UserEmailID"];
        
        NSLog(@"Name :%@",[[userArray objectAtIndex:indexSelected] objectForKey:@"UserName"]);
        NSLog(@"Phone No :%@",[[userArray objectAtIndex:indexSelected] objectForKey:@"UserPhoneNo"]) ;
        NSLog(@"Email ID :%@",[[userArray objectAtIndex:indexSelected] objectForKey:@"UserEmailID"]);
        NSLog(@"Image :%@",[[userArray objectAtIndex:indexSelected] objectForKey:@"ProfileImageFile"]);
        
        PFFile *eventImage = [[userArray objectAtIndex:indexSelected] objectForKey:@"ProfileImageFile"];
        
        if(eventImage != NULL)
        {
            
            [eventImage getDataInBackgroundWithBlock:^(NSData *imageData, NSError *error) {
                
                UIImage *thumbnailImage = [UIImage imageWithData:imageData];
                UIImageView *thumbnailImageView = [[UIImageView alloc] initWithImage:thumbnailImage];
                
                self.profileImageView.image = thumbnailImageView.image;
                
            }];
            
        }
        [self.spinner stopAnimating];
    }
    else
    {
        self.updateButton.hidden=YES;
        self.navigationItem.rightBarButtonItem.enabled = NO;
        deleteButton.hidden=YES;

    }
    
}
-(void)back
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)StartActivityIndicator
{
    [self.spinner startAnimating];
    
}
-(IBAction)updateButtonAction:(id)sender
{
    
    [NSThread detachNewThreadSelector:@selector(StartActivityIndicator) toTarget:self withObject:nil];
    
    PFQuery *updatequery = [PFQuery queryWithClassName:@"UserDetails"];
    
    NSArray *updateduserArray=[updatequery findObjects];
    
    // Create the object.
    
    PFObject *userInfoObj = [updateduserArray objectAtIndex:indexSelected];
    
    // Now let's update it with some new data. In this case, only cheatMode and score
    // will get sent to the cloud. playerName hasn't changed.
    
    [userInfoObj setObject:@"angelina@gmail.com" forKey:@"UserEmailID"];
    [userInfoObj setObject:@"Angelina" forKey:@"UserName"];
  
    NSData *imageData = UIImagePNGRepresentation(self.profileImageView.image);
    
    PFFile *imageFile = [PFFile fileWithName:@"profileimage.png" data:imageData];
    [imageFile save];
    
    [userInfoObj setObject:self.nameTextField.text forKey:@"UserName"];
    [userInfoObj setObject:self.phoneNoTextField.text forKey:@"UserPhoneNo"];
    [userInfoObj setObject:self.emailIDTextField.text forKey:@"UserEmailID"];
    [userInfoObj setObject:[NSDate date] forKey:@"Date"];
    [userInfoObj setObject:imageFile forKey:@"ProfileImageFile"];
    [userInfoObj saveInBackground];
    
    [self.spinner stopAnimating];
    
    UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:@"Parse API" message:@"Data Updated successfully" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    
    [alertView show];

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)setViewMovedUp :(BOOL)movedUp
{
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    
    CGRect rect = self.view.frame;
    
                if (movedUp)
                {
                if(currentTextField.tag==1)
                {
                    //rect.origin.y = -40;
                    rect.origin.y =-20;
                }
                else if(currentTextField.tag==2)
                {
                    
                    //rect.origin.y = -40;
                    rect.origin.y =-120;
                }
                
            }
            else
            {
                rect.origin.y =0;
                
            }
            
    self.view.frame = rect;
    [UIView commitAnimations];
}

-(void)delete:(id)sender
{
  //  PFObject *userObject=[PFObject objectWithClassName:@"UserDetails"];
    
    [NSThread detachNewThreadSelector:@selector(StartActivityIndicator) toTarget:self withObject:nil];
    
    PFObject *object = [PFObject objectWithoutDataWithClassName:@"UserDetails" objectId:self.delObjId];
    [object deleteInBackground];
    
    //[userInfo delete];
    
    //NSLog(@"userObject ------> %@",userInfo);
    
    [self.spinner stopAnimating];
    
    UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:@"Parse API" message:@"Data Deleted successfully" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    
    [alertView show];
}

#pragma mark -

#pragma mark TextField Delegates
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if(textField.tag==1)
    {
        [textField resignFirstResponder];
    }
    else if(textField.tag==2)
    {
        [textField resignFirstResponder];
    }
    else if(textField.tag==3)
    {
        [textField resignFirstResponder];
    }
	[self setViewMovedUp:NO];
	return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    
    if(textField.tag==1)
    {
        
    }
    else if(textField.tag==2)
    {
    }
    
	return YES;
}

-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    currentTextField=textField;
    [self setViewMovedUp:NO];
}

-(void)textFieldDidEndEditing:(UITextField *)textField
{
    
    //nslog(@"textfield %@",textField);
    
    if(textField.tag==1)
    {
    }
    else if(textField.tag==2)
    {
    }
    else if(textField.tag==3)
    {
        
    }
    ////nslog(@"quantityTextField.text is %@",quantityTextField.text);
    
}
#pragma mark end of TextField Delegates
-(IBAction)saveButtonAction:(id)sender
{
    [NSThread detachNewThreadSelector:@selector(StartActivityIndicator) toTarget:self withObject:nil];
    
    NSData *imageData = UIImagePNGRepresentation(selectedImage);
    
    PFFile *imageFile = [PFFile fileWithName:@"profileimage.png" data:imageData];
    [imageFile save];
    
    userInfo = [PFObject objectWithClassName:@"UserDetails"];
    [userInfo setObject:self.nameTextField.text forKey:@"UserName"];
    [userInfo setObject:self.phoneNoTextField.text forKey:@"UserPhoneNo"];
    [userInfo setObject:self.emailIDTextField.text forKey:@"UserEmailID"];
    [userInfo setObject:[NSDate date] forKey:@"Date"];
    [userInfo setObject:imageFile forKey:@"ProfileImageFile"];
    
   // [userInfo saveInBackground];
    [userInfo save];
    
    NSLog(@"Object id %@",[userInfo objectId]);
    
    NSString *objId = [userInfo objectId];
    
    [userInfo setObject:objId forKey:@"objid"];
    
    [userInfo save];
    
    [self.spinner stopAnimating];
    
    UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:@"Parse API" message:@"Data saved successfully" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    
    [alertView show];
    
    //[self retrieveDetails];
}
- (void)retrieveDetails
{
    PFQuery *query = [PFQuery queryWithClassName:@"UserDetails"];
    __block int totalNumberOfEntries = 0;
    [query orderByDescending:@"createdAt"];
    [query countObjectsInBackgroundWithBlock:^(int number1, NSError *error)
    {
        if (!error)
        {
            // The count request succeeded. Log the count
            NSLog(@"There are currently %d entries", number1);
            totalNumberOfEntries = number1;
            NSLog(@"------- number-- %d",number1);
            NSLog(@"------- number-- %d",[profileArray count]);
            if (totalNumberOfEntries > [profileArray count])
            {
                NSLog(@"Retrieving data");
                //query.skip=[NSNumber numberWithInt:2300];
                [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
                    if (!error) {
                        // The find succeeded.
                        NSLog(@"Successfully retrieved %d chats.", objects.count);
                        int j=[profileArray count];
                        if([objects count]>j)
                        {
                            [profileArray addObjectsFromArray:objects];
                            
                            NSLog(@"array count is %d",[profileArray count]);
                            
                            NSLog(@"array is %@",profileArray);                            
                        }
                    }
                    else
                    {
                        // Log details of the failure
                        NSLog(@"Error: %@ %@", error, [error userInfo]);
                    }
                }];
            }
            
        } else
        {
            // The request failed, we'll keep the chatData count?
            number1 = [profileArray count];
        }
    }];

}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    if (actionSheet.tag==1)
    {
        switch (actionSheet.tag)
        {
            case 1:
                switch (buttonIndex)
            {
                case 0:
                {
                            
#if TARGET_IPHONE_SIMULATOR
                    
                    UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"Message" message:@"Camera not available." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                    [alert show];
                    
#elif TARGET_OS_IPHONE
                    
                    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
                    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
                    picker.delegate = self;
                    //picker.allowsEditing = YES;
                    [self presentModalViewController:picker animated:YES];
                    
                    
#endif
                }
                    break;
                case 1:
                {
                    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
                    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                    picker.delegate = self;
                    [self presentModalViewController:picker animated:YES];
                }
                    break;
                    
                default:
                    ///  //nslog(@"cancel case");
                    //NSString *image=@"profileimage.png";
                    //profileImageView.image=[UIImage imageNamed:image];
                    
                    break;
                    
            }
                
            default:
                
                break;
        }
        
    }
}

#pragma mark-taking profile image from gallery or camera
-(IBAction)imageButtonPressed:(id) sender
{
        CGRect frame=self.view.frame;
        frame.origin.y=0;
        self.view.frame=frame;
        //profileImageView.image=nil;
        
        UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"Choose a pic" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Take a picture",@"Gallery", nil];
        actionSheet.actionSheetStyle = UIActionSheetStyleBlackTranslucent;
        actionSheet.alpha=0.90;
        actionSheet.tag = 1;
        
        [actionSheet showInView:[[UIApplication sharedApplication] keyWindow]];
}

-(void)imagePickerController:(UIImagePickerController*)picker didFinishPickingMediaWithInfo:(NSDictionary*)info
{
    
    
    [currentTextField resignFirstResponder];
    
    selectedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    
    selectedImage = [self scaleAndRotateImage:selectedImage];
    ////nslog(@"selectedImage:%@",selectedImage);
    
    [self.profileImageView setImage:selectedImage];

    [picker dismissModalViewControllerAnimated:YES];
    
   }

-(NSString *)returningstring:(id)string
{
    if ([string isKindOfClass:[NSNull class]])
    {
        return @" ";
    }
    else
    {
        if (![string isKindOfClass:[NSString class]])
        {
            NSString *str= [string stringValue];
            return str;
        }
        else
        {
            return string;
        }
    }
    
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
	[self.navigationController dismissModalViewControllerAnimated:YES];
}

-(UIImage *)scaleAndRotateImage:(UIImage *)image
{
	int kMaxResolution = 400; // Or whatever
	//int kMaxResolution = 640;
	
	CGImageRef imgRef = image.CGImage;
	
	CGFloat width = CGImageGetWidth(imgRef);
	CGFloat height = CGImageGetHeight(imgRef);
	
	CGAffineTransform transform = CGAffineTransformIdentity;
	CGRect bounds = CGRectMake(0, 0, width, height);
	if (width > kMaxResolution || height > kMaxResolution) {
		CGFloat ratio = width/height;
		if (ratio > 1) {
			bounds.size.width = kMaxResolution;
			bounds.size.height = bounds.size.width / ratio;
		}
		else {
			bounds.size.height = kMaxResolution;
			bounds.size.width = bounds.size.height * ratio;
		}
	}
	
	CGFloat scaleRatio = bounds.size.width / width;
	CGSize imageSize = CGSizeMake(CGImageGetWidth(imgRef), CGImageGetHeight(imgRef));
	CGFloat boundHeight;
	UIImageOrientation orient = image.imageOrientation;
	//    self.imgOrientation=image.imageOrientation;
	
	switch(orient) {
			
		case UIImageOrientationUp: //EXIF = 1
			transform = CGAffineTransformIdentity;
			break;
			
		case UIImageOrientationUpMirrored: //EXIF = 2
			transform = CGAffineTransformMakeTranslation(imageSize.width, 0.0);
			transform = CGAffineTransformScale(transform, -1.0, 1.0);
			break;
			
		case UIImageOrientationDown: //EXIF = 3
			transform = CGAffineTransformMakeTranslation(imageSize.width, imageSize.height);
			transform = CGAffineTransformRotate(transform, M_PI);
			break;
			
		case UIImageOrientationDownMirrored: //EXIF = 4
			transform = CGAffineTransformMakeTranslation(0.0, imageSize.height);
			transform = CGAffineTransformScale(transform, 1.0, -1.0);
			break;
			
		case UIImageOrientationLeftMirrored: //EXIF = 5
			boundHeight = bounds.size.height;
			bounds.size.height = bounds.size.width;
			bounds.size.width = boundHeight;
			transform = CGAffineTransformMakeTranslation(imageSize.height, imageSize.width);
			transform = CGAffineTransformScale(transform, -1.0, 1.0);
			transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
			break;
			
		case UIImageOrientationLeft: //EXIF = 6
			boundHeight = bounds.size.height;
			bounds.size.height = bounds.size.width;
			bounds.size.width = boundHeight;
			transform = CGAffineTransformMakeTranslation(0.0, imageSize.width);
			transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
			break;
			
		case UIImageOrientationRightMirrored: //EXIF = 7
			boundHeight = bounds.size.height;
			bounds.size.height = bounds.size.width;
			bounds.size.width = boundHeight;
			transform = CGAffineTransformMakeScale(-1.0, 1.0);
			transform = CGAffineTransformRotate(transform, M_PI / 2.0);
			break;
			
		case UIImageOrientationRight: //EXIF = 8
			boundHeight = bounds.size.height;
			bounds.size.height = bounds.size.width;
			bounds.size.width = boundHeight;
			transform = CGAffineTransformMakeTranslation(imageSize.height, 0.0);
			transform = CGAffineTransformRotate(transform, M_PI / 2.0);
			break;
			
		default:
			[NSException raise:NSInternalInconsistencyException format:@"Invalid image orientation"];
			
	}
	
	UIGraphicsBeginImageContext(bounds.size);
	
	CGContextRef context = UIGraphicsGetCurrentContext();
	
	if (orient == UIImageOrientationRight || orient == UIImageOrientationLeft) {
		CGContextScaleCTM(context, -scaleRatio, scaleRatio);
		CGContextTranslateCTM(context, -height, 0);
	}
	else {
		CGContextScaleCTM(context, scaleRatio, -scaleRatio);
		CGContextTranslateCTM(context, 0, -height);
	}
	
	CGContextConcatCTM(context, transform);
	
	CGContextDrawImage(UIGraphicsGetCurrentContext(), CGRectMake(0, 0, width, height), imgRef);
	UIImage *imageCopy = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
	
	return imageCopy;
}

@end
