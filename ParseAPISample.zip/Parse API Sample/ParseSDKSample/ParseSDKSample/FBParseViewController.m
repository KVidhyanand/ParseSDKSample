//
//  FBParseViewController.m
//  ParseSDKSample
//
//  Created by Stellent Software on 8/12/13.
//  Copyright (c) 2013 Stellent Software. All rights reserved.
//

#import "FBParseViewController.h"

@interface FBParseViewController ()

@end

@implementation FBParseViewController

@synthesize idLabel;
@synthesize nameLabel;
@synthesize locationLabel;
@synthesize genderLabel;
@synthesize profileImgView;
@synthesize birthdayLabel;
@synthesize relationship_statusLabel;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        self.title=@"Facebook User Details";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    UIImage *deleteImage = [UIImage imageNamed:@"logout_nav.png"];
	UIButton *deleteButton = [UIButton buttonWithType:UIButtonTypeCustom];
	[deleteButton setImage:deleteImage forState:UIControlStateNormal];
	deleteButton.showsTouchWhenHighlighted = YES;
	deleteButton.frame = CGRectMake(0.0, 3.0, 75,32);
	[deleteButton addTarget:self action:@selector(logoutButtonTouchHandler:) forControlEvents:UIControlEventTouchUpInside];
	UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithCustomView:deleteButton];
	self.navigationItem.rightBarButtonItem = rightButton;

    
    FBRequest *request = [FBRequest requestForMe];
    
    // Send request to Facebook
    [request startWithCompletionHandler:^(FBRequestConnection *connection, id result, NSError *error) {
        // handle response
        
        if (!error) {
            // result is a dictionary with the user's Facebook data
            NSDictionary *userData = (NSDictionary *)result;
            
            NSString *facebookID = userData[@"id"];
            
            self.idLabel.text=facebookID;
            
            NSString *name = userData[@"name"];
            
            self.nameLabel.text=name;
            
            NSString *location = userData[@"location"][@"name"];
            
            self.locationLabel.text=location;
            
            NSString *gender = userData[@"gender"];
            
            self.genderLabel.text=gender;
            
            NSString *birthday = userData[@"birthday"];
            
            self.birthdayLabel.text=birthday;
            
            NSString *relationship = userData[@"relationship_status"];
            
            self.relationship_statusLabel.text=relationship;
            
            
            NSURL *pictureURL = [NSURL URLWithString:[NSString stringWithFormat:@"https://graph.facebook.com/%@/picture?type=large&return_ssl_resources=1", facebookID]];
            
            // Now add the data to the UI elements
            // ...
            
            // Download the user's facebook profile picture
            imageData = [[NSMutableData alloc] init]; // the data will be loaded in here
            
            // URL should point to https://graph.facebook.com/{facebookId}/picture?type=large&return_ssl_resources=1
            NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:pictureURL
                                                                      cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                                  timeoutInterval:2.0f];
            // Run network request asynchronously
            urlConnection = [[NSURLConnection alloc] initWithRequest:urlRequest delegate:self];
        }
    }];
    
}

// Called every time a chunk of the data is received
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    [imageData appendData:data]; // Build the image
}

// Called when the entire image is finished downloading
- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    // Set the image in the header imageView
    profileImgView.image = [UIImage imageWithData:imageData];
}
- (void)logoutButtonTouchHandler:(id)sender
{
    [PFUser logOut];
    
    // Return to login page

    [self.navigationController popToRootViewControllerAnimated:YES];
    
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
