//
//  ViewController.h
//  ParseSDKSample
//
//  Created by Stellent Software on 7/25/13.
//  Copyright (c) 2013 Stellent Software. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ParseDetailsViewController.h"
#import "AddParseDetailsViewController.h"
#import "FBParseViewController.h"
#import "FBFriendsViewController.h"
#import "TwitterViewController.h"
#import <Parse/Parse.h>
#import <EventKit/EventKit.h>
#import <QuartzCore/QuartzCore.h>

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

{
    EKEventStore *eventStore;
}

@property(nonatomic,strong)IBOutlet UITableView *contentTableView;

@property(nonatomic,strong)NSMutableArray *contentsArray;

@end
