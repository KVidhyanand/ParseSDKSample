//
//  ParseObject.m
//  ParseSDKSample
//
//  Created by Stellent Software on 7/25/13.
//  Copyright (c) 2013 Stellent Software. All rights reserved.
//

#import "ParseObject.h"

@implementation ParseObject

@synthesize dateLabel;
@synthesize nameLabel;
@synthesize profileImage;
@synthesize phonenoLabel;
@synthesize emailLabel;

@end
