//
//  ParseDetailsViewController.h
//  ParseSDKSample
//
//  Created by Stellent Software on 7/25/13.
//  Copyright (c) 2013 Stellent Software. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ParseDetailsCell.h"
#import <Parse/Parse.h>
#import "AddParseDetailsViewController.h"
#import <QuartzCore/QuartzCore.h>

@interface ParseDetailsViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    NSArray *userArray;
}
@property(nonatomic,strong)IBOutlet UIActivityIndicatorView *spinner;
@property(nonatomic,strong)IBOutlet UITableView *detailsTableView;
@property(nonatomic,strong)NSMutableArray *detailsArray;
@property(nonatomic,strong)IBOutlet ParseDetailsCell *parseCell;
@property(nonatomic,strong) NSString *objId;

@end
