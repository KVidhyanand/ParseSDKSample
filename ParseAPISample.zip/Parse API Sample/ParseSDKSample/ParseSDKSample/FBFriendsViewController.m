//
//  FBFriendsViewController.m
//  ParseSDKSample
//
//  Created by Stellent Software on 8/12/13.
//  Copyright (c) 2013 Stellent Software. All rights reserved.
//

#import "FBFriendsViewController.h"

@interface FBFriendsViewController ()

@end

@implementation FBFriendsViewController
@synthesize contentsArray;
@synthesize contentTableView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        self.title=@"Facebook Friends";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    contentsArray=[[NSMutableArray alloc]init];
    
    [self fbFriends];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)fbFriends
{
    
    NSArray *permissionsArray = @[ @"user_about_me", @"user_relationships", @"user_birthday", @"user_location",@"friends_about_me",@"publish_stream",@"publish_actions"];
    
    
    [PFFacebookUtils logInWithPermissions:permissionsArray
                                    block:^(PFUser *user, NSError *error) {
                                        if (user) {
                                            [FBRequestConnection startForMeWithCompletionHandler:^(FBRequestConnection *connection, id result, NSError *error) {
                                                if (!error) {
                                                    // Store the current user's Facebook ID on the user
                                                    [[PFUser currentUser] setObject:[result objectForKey:@"id"]
                                                                             forKey:@"fbId"];
                                                    
                                                    [[PFUser currentUser] saveInBackground];
                                                }
                                            }];
                                        }
                                    }];
    
    
    [FBRequestConnection startForMyFriendsWithCompletionHandler:^(FBRequestConnection *connection, id result, NSError *error) {
        if (!error) {
            // result will contain an array with your user's friends in the "data" key
            
            NSLog(@"result:%@",result);
            
            /*
             
             result:{
             data =     (
             {
             "first_name" = Suresh;
             id = 100004003870067;
             "last_name" = Stellent;
             name = "Suresh Stellent";
             username = "suresh.stellent";
             },
             {
             "first_name" = Satish;
             id = 100005060501896;
             "last_name" = Jackson;
             name = "Satish Jackson";
             username = "satish.jackson.1";
             }
             );
             paging =     {
             next = "https://graph.facebook.com/100003818907083/friends?fields=id,name,username,first_name,last_name&format=json&access_token=CAACtllZA9WRwBAN8ZAiWVLXdeD33ZCt0en1qR3vQxePz0pinQqssgzWTgz5cJ1ZCjslKv2heA9gGU1myYzqhsCw9C3YJpRzu3OK6qKiZCnccF5pxCiC3ShHeWTW1JZAv8OsQYaw5rEGOxlA2FthWSInYzlZBG41N8bbSuMlQruaVVABI62leMq46oZBLFUu3lGkZD&limit=5000&offset=5000&__after_id=100005060501896";
             };
             }

             */
            
            NSArray *friendObjects = [result objectForKey:@"data"];
            NSMutableArray *friendIds = [NSMutableArray arrayWithCapacity:friendObjects.count];
            // Create a list of friends' Facebook IDs
            for (NSDictionary *friendObject in friendObjects) {
                [friendIds addObject:[friendObject objectForKey:@"id"]];
                [contentsArray addObject:[friendObject objectForKey:@"name"]];
                
                NSLog(@"contentsArray:%@",contentsArray);
            }
            [self.contentTableView reloadData];
            // Construct a PFUser query that will find friends whose facebook ids
            // are contained in the current user's friend list.
            PFQuery *friendQuery = [PFUser query];
            
            [friendQuery whereKey:@"fbId" containedIn:friendIds];
            
            //findObjects will return a list of PFUsers that are friends
            // with the current user
            NSArray *friendUsers = [friendQuery findObjects];
            
            NSLog(@"FB Friends Array is:%@",friendUsers);
        }
    }];
    
    
}

#pragma mark---Tableview delegate methods

-(NSInteger) numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [contentsArray count];
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    
    if(cell==nil)
    {
        
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
        
        
    }
    
    cell.textLabel.text=[contentsArray objectAtIndex:indexPath.row];
    
    cell.textLabel.textColor=[UIColor blackColor];
    
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    //cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    
    return cell;
    
}

@end
