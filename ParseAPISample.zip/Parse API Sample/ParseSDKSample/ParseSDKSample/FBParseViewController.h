//
//  FBParseViewController.h
//  ParseSDKSample
//
//  Created by Stellent Software on 8/12/13.
//  Copyright (c) 2013 Stellent Software. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <FacebookSDK/FacebookSDK.h>
#import <Parse/Parse.h>

@interface FBParseViewController : UIViewController
{
    NSMutableData *imageData;
    NSURLConnection *urlConnection;
    NSString *fbidString;
}

@property(nonatomic,strong)IBOutlet UILabel *idLabel;
@property(nonatomic,strong)IBOutlet UILabel *nameLabel;
@property(nonatomic,strong)IBOutlet UILabel *locationLabel;
@property(nonatomic,strong)IBOutlet UILabel *genderLabel;
@property(nonatomic,strong)IBOutlet UILabel *birthdayLabel;
@property(nonatomic,strong)IBOutlet UILabel *relationship_statusLabel;

@property(nonatomic,strong)IBOutlet UIImageView *profileImgView;
@end
