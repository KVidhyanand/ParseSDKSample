//
//  ViewController.m
//  ParseSDKSample
//
//  Created by Stellent Software on 7/25/13.
//  Copyright (c) 2013 Stellent Software. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize contentsArray;
@synthesize contentTableView;

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    self.navigationController.navigationBarHidden=NO;
    
    contentsArray=[[NSMutableArray alloc] initWithObjects:@"Add Parse Object Details",@"View Parse Object Details",@"Facebook Profile Details",@"Facebook Friends List",@"Twitter", nil];
    
    float version = [[[UIDevice currentDevice] systemVersion] floatValue];
    NSLog(@"Current my iOS version is %0.2f",version);
    
    NSString *navBarImageName =  @"navBar.png" ;
    if (version>=5.00)
    {
        [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:navBarImageName] forBarMetrics:UIBarMetricsDefault];
        // [self.navigationController.navigationBar setBackgroundImage:nil forBarMetrics:UIBarMetricsDefault];
    }
	
	else
    {
        self.navigationController.navigationBar.layer.contents = (id)[UIImage imageNamed:navBarImageName].CGImage;
        
    }
	//-------Navigation bar image end
    
   
    UIImage *deleteImage = [UIImage imageNamed:@"login_nav.png"];
	UIButton *deleteButton = [UIButton buttonWithType:UIButtonTypeCustom];
	[deleteButton setImage:deleteImage forState:UIControlStateNormal];
	deleteButton.showsTouchWhenHighlighted = YES;
	deleteButton.frame = CGRectMake(0.0, 3.0, 75,32);
	[deleteButton addTarget:self action:@selector(loginButtonTouchHandler:) forControlEvents:UIControlEventTouchUpInside];
	UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithCustomView:deleteButton];
	self.navigationItem.rightBarButtonItem = rightButton;
   
   // [self performSelector:@selector(loginButtonTouchHandler:) withObject:nil afterDelay:0.1];
    
    if ([PFUser currentUser] && // Check if a user is cached
        [PFFacebookUtils isLinkedWithUser:[PFUser currentUser]]) // Check if user is linked to Facebook
    {
        // Push the next view controller without animation
        FBParseViewController *fbParseVC=[[FBParseViewController alloc]initWithNibName:@"FBParseViewController" bundle:nil];
        [self.navigationController pushViewController:fbParseVC animated:NO];
    }
    
}

#pragma mark---Tableview delegate methods

-(NSInteger) numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [contentsArray count];
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    
    if(cell==nil)
    {
        
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
        
        
    }
    
    cell.textLabel.text=[contentsArray objectAtIndex:indexPath.row];
    
    cell.textLabel.textColor=[UIColor whiteColor];
    
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    
    return cell;
    
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row==0)
    {
        AddParseDetailsViewController *addParseVC=[[AddParseDetailsViewController alloc]initWithNibName:@"AddParseDetailsViewController" bundle:nil];
        addParseVC.comingString=@"New";
        [self.navigationController pushViewController:addParseVC animated:YES];
    }
    else  if (indexPath.row==1)
    {
        ParseDetailsViewController *parseDetailsVC=[[ParseDetailsViewController alloc]initWithNibName:@"ParseDetailsViewController" bundle:nil];
        
        [self.navigationController pushViewController:parseDetailsVC animated:YES];

    }
    else if (indexPath.row==2)
    {
        FBParseViewController *fbParseVC=[[FBParseViewController alloc]initWithNibName:@"FBParseViewController" bundle:nil];
        [self.navigationController pushViewController:fbParseVC animated:YES];
    }
    else if (indexPath.row==3)
    {
        FBFriendsViewController *fbFriendsVC=[[FBFriendsViewController alloc]initWithNibName:@"FBFriendsViewController" bundle:nil];
        [self.navigationController pushViewController:fbFriendsVC animated:YES];

    }
    else
    {
        TwitterViewController *twitterVC=[[TwitterViewController alloc]initWithNibName:@"TwitterViewController" bundle:nil];
        [self.navigationController pushViewController:twitterVC animated:YES];
        
    }
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}
- (IBAction)loginButtonTouchHandler:(id)sender  {
    // The permissions requested from the user
    NSArray *permissionsArray = @[ @"user_about_me", @"user_relationships", @"user_birthday", @"user_location"];
    
    // Login PFUser using Facebook
    [PFFacebookUtils logInWithPermissions:permissionsArray block:^(PFUser *user, NSError *error) {
       // [_activityIndicator stopAnimating]; // Hide loading indicator
        
            if (!user) {
            if (!error) {
                NSLog(@"Uh oh. The user cancelled the Facebook login.");
            } else {
                NSLog(@"Uh oh. An error occurred: %@", error);
            }
        } else if (user.isNew)
        {
            NSLog(@"User with facebook signed up and logged in!");
            
           // [self.navigationController pushViewController:fbParseVC animated:YES];
           // [self.navigationController pushViewController:[[FBParseViewController alloc] initWithStyle:UITableViewStyleGrouped] animated:YES];
        } else
        {
            NSLog(@"User with facebook logged in!");
            
            //[self.navigationController pushViewController:fbParseVC animated:YES];
           // [self.navigationController pushViewController:[[FBParseViewController alloc] initWithStyle:UITableViewStyleGrouped] animated:YES];
        }
    }];
    /*
    FBRequest *request = [FBRequest requestForMe];
    [request startWithCompletionHandler:^(FBRequestConnection *connection, id result, NSError *error) {
        if (!error) {
            // handle successful response
        } else if ([error.userInfo[FBErrorParsedJSONResponseKey][@"body"][@"error"][@"type"] isEqualToString:@"OAuthException"]) { // Since the request failed, we can check if it was due to an invalid session
            NSLog(@"The facebook session was invalidated");
            [self logoutButtonTouchHandler:nil];
        } else
        {
            NSLog(@"Some other error: %@", error);
        }
    }];
     */
}
- (void)logoutButtonTouchHandler:(id)sender
{
    
    [PFUser logOut];
    
    // Return to login page
    [self.navigationController popToRootViewControllerAnimated:YES];
}
- (void)viewWillAppear:(BOOL)animated
{
    PFQuery *pushQuery = [PFInstallation query];
    [pushQuery whereKey:@"deviceType" equalTo:@"ios"];
    
    // Send push notification to query
    [PFPush sendPushMessageToQueryInBackground:pushQuery
                                   withMessage:@"Hello World!"];
    
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}


@end
