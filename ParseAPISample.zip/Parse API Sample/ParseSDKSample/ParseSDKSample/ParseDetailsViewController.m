//
//  ParseDetailsViewController.m
//  ParseSDKSample
//
//  Created by Stellent Software on 7/25/13.
//  Copyright (c) 2013 Stellent Software. All rights reserved.
//

#import "ParseDetailsViewController.h"

@interface ParseDetailsViewController ()

@end

@implementation ParseDetailsViewController

@synthesize parseCell;

@synthesize detailsArray,detailsTableView;
@synthesize objId;
@synthesize spinner;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        self.title=@"Parse Users Details";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    detailsArray=[[NSMutableArray alloc]init];
    
    self.title=@"Users Details";
    
    self.spinner.hidesWhenStopped=YES;
    
    float version = [[[UIDevice currentDevice] systemVersion] floatValue];
    NSLog(@"Current my iOS version is %0.2f",version);
    
    NSString *navBarImageName =  @"navBar.png" ;
    if (version>=5.00)
    {
        [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:navBarImageName] forBarMetrics:UIBarMetricsDefault];
        // [self.navigationController.navigationBar setBackgroundImage:nil forBarMetrics:UIBarMetricsDefault];
    }
	
	else {
        self.navigationController.navigationBar.layer.contents = (id)[UIImage imageNamed:navBarImageName].CGImage;
        
    }
	//-------Navigation bar image end
    
    
    //-------back button  start
	UIImage *myImage1 = [UIImage imageNamed:@"back_btn.png"];
	UIButton *myButton1 = [UIButton buttonWithType:UIButtonTypeCustom];
	[myButton1 setImage:myImage1 forState:UIControlStateNormal];
	myButton1.showsTouchWhenHighlighted = YES;
	myButton1.frame = CGRectMake(0.0, 3.0, 50,30);
	[myButton1 addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
	UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithCustomView:myButton1];
	self.navigationItem.leftBarButtonItem = leftButton;
    //-------back button  end

    
   // PFQuery *query = [PFQuery queryWithClassName:@"UserDetails"];
    //userArray=[query findObjects];
    
    
   /* PFQuery *query = [PFQuery queryWithClassName:@"UserDetails"];
    userArray=[query findObjects];
    
    PFObject *object = [PFObject objectWithClassName:@"UserDetails"];
    [object save];
    NSLog(@"Object id %@",[object objectId]);
    
    objId = [object objectId];
    
    NSLog(@"userArray ====%@",userArray);
    
   // [self.detailsTableView reloadData];*/

}
-(void)back
{
    [self.navigationController popToRootViewControllerAnimated:YES];
}
-(void)StartActivityIndicator
{
    [self.spinner startAnimating];
    
}


-(void)viewWillAppear:(BOOL)animated
{
    [NSThread detachNewThreadSelector:@selector(StartActivityIndicator) toTarget:self withObject:nil];
    
    PFQuery *query = [PFQuery queryWithClassName:@"UserDetails"];
    userArray=[query findObjects];
    
   // PFObject *object = [PFObject objectWithClassName:@"UserDetails"];
   // [object save];
  //  NSLog(@"Object id %@",[object objectId]);
    
    NSLog(@"userArray ====%@",userArray);
    
    [self.spinner stopAnimating];
    
    [self.detailsTableView reloadData];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark---Tableview delegate methods

-(NSInteger) numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [userArray count];
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 135;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier=@"cell";
    
    ParseDetailsCell *cell=(ParseDetailsCell *)[detailsTableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell==nil)
    {
        [[NSBundle mainBundle] loadNibNamed:@"ParseDetailsCell" owner:self options:nil];
        cell=self.parseCell;
    }
    
    // Do something with the returned PFObject in the gameScore variable.
    NSLog(@"User Details%@", userArray);
    
    NSLog(@"Name :%@",[[userArray objectAtIndex:indexPath.row] objectForKey:@"UserName"]);
    NSLog(@"Phone No :%@",[[userArray objectAtIndex:indexPath.row] objectForKey:@"UserPhoneNo"]) ;
    NSLog(@"Email ID :%@",[[userArray objectAtIndex:indexPath.row] objectForKey:@"UserEmailID"]);
    NSLog(@"Image :%@",[[userArray objectAtIndex:indexPath.row] objectForKey:@"ProfileImageFile"]);
    
    NSLog(@"id :%@",[[userArray objectAtIndex:indexPath.row] objectForKey:@"objid"]);
    
    cell.nameLabel.text=[[userArray objectAtIndex:indexPath.row] objectForKey:@"UserName"];
    cell.phonenoLabel.text=[[userArray objectAtIndex:indexPath.row] objectForKey:@"UserPhoneNo"];
    cell.emailLabel.text=[[userArray objectAtIndex:indexPath.row] objectForKey:@"UserEmailID"];
    
    
    PFFile *eventImage = [[userArray objectAtIndex:indexPath.row] objectForKey:@"ProfileImageFile"];
    
    if(eventImage != NULL)
    {
        
        [eventImage getDataInBackgroundWithBlock:^(NSData *imageData, NSError *error) {
            
            UIImage *thumbnailImage = [UIImage imageWithData:imageData];
            UIImageView *thumbnailImageView = [[UIImageView alloc] initWithImage:thumbnailImage];
            
            cell.profileImage.image = thumbnailImageView.image;
            
        }];
        
    }

    NSDate *theDate = [[userArray objectAtIndex:indexPath.row] objectForKey:@"Date"];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    //[formatter setDateFormat:@"dd/MM/yy hh:mm a"];//@"HH:mm a"
    [formatter setDateFormat:@"cccc, LLLL d hh:mm a"];//@"HH:mm a"
    NSString *timeString = [formatter stringFromDate:theDate];
    cell.dateLabel.text = timeString;
    cell.dateLabel.textColor=[UIColor whiteColor];
    cell.nameLabel.textColor=[UIColor whiteColor];
    cell.phonenoLabel.textColor=[UIColor whiteColor];
    cell.emailLabel.textColor=[UIColor whiteColor];
    
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    //cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    
    return cell;
    
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
        AddParseDetailsViewController *addParseVC=[[AddParseDetailsViewController alloc]initWithNibName:@"AddParseDetailsViewController" bundle:nil];
    addParseVC.indexSelected=indexPath.row;
    addParseVC.delObjId = [[userArray objectAtIndex:indexPath.row] objectForKey:@"objid"];
    addParseVC.comingString=@"Update";
        [self.navigationController pushViewController:addParseVC animated:YES];
}
@end
