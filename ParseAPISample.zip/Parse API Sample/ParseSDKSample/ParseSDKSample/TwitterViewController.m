//
//  TwitterViewController.m
//  ParseSDKSample
//
//  Created by Stellent Software on 8/23/13.
//  Copyright (c) 2013 Stellent Software. All rights reserved.
//

#import "TwitterViewController.h"

@interface TwitterViewController ()

@end

@implementation TwitterViewController

@synthesize detailsArray;
@synthesize detailsTableView;
@synthesize parseCell;
@synthesize spinner;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        self.title=@"Tweets";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    detailsArray=[[NSMutableArray alloc]init];
    
    externaldictionary=[[NSDictionary alloc]init];
    
    [self.spinner startAnimating];
    
    [self tweetsMethod];

    
    
   /*
    if (![PFTwitterUtils isLinkedWithUser:[PFUser currentUser]]) {
        [PFTwitterUtils linkUser:[PFUser currentUser] block:^(BOOL succeeded, NSError *error) {
            if ([PFTwitterUtils isLinkedWithUser:[PFUser currentUser]])
            {
                NSLog(@"Woohoo, user logged in with Twitter!");
            }
        }];
    }
    */
    
    /*
    [PFTwitterUtils unlinkUserInBackground:[PFUser currentUser] block:^(BOOL succeeded, NSError *error) {
        if (!error && succeeded) {
            NSLog(@"The user is no longer associated with their Twitter account.");
        }
    }];
   */
    
    
    /*
    NSError *error;
    
    NSURL *verify = [NSURL URLWithString:@"https://api.twitter.com/1/account/verify_credentials.json"];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:verify];
    [[PFTwitterUtils twitter] signRequest:request];
    NSURLResponse *response = nil;
    NSData *data = [NSURLConnection sendSynchronousRequest:request
                                         returningResponse:&response
                                                     error:&error];
    NSLog(@"Response is:%@",data);
     
     */
}
//-(IBAction)twitterAction:(id)sender
-(void)tweetsMethod
{
    [detailsArray removeAllObjects];
    
    [PFTwitterUtils logInWithBlock:^(PFUser *user, NSError *error)
     {
         if (!user)
         {
             NSLog(@"Uh oh. The user cancelled the Twitter login.");
             return;
         }
         
         else if (user.isNew)
         
         {
             NSLog(@"User signed up and logged in with Twitter!");
             
             NSError *error;
             
             NSURL *verify = [NSURL URLWithString:@"https://api.twitter.com/1.1/statuses/user_timeline.json"];
             
             //https://api.twitter.com/1/account/verify_credentials.json
             NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:verify];
             [[PFTwitterUtils twitter] signRequest:request];
             NSURLResponse *response = nil;
             NSData *data = [NSURLConnection sendSynchronousRequest:request
                                                  returningResponse:&response
                                                              error:&error];
             
             
             html  = [[NSString alloc] initWithData:data
                                                     encoding:NSUTF8StringEncoding];
             //NSLog(@"Response is:%@",html);
         }
         
         else
         
         {
             NSLog(@"User logged in with Twitter!");
             
             NSError *error;
             
             NSURL *verify = [NSURL URLWithString:@"https://api.twitter.com/1.1/statuses/user_timeline.json"];
             
             NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:verify];
             [[PFTwitterUtils twitter] signRequest:request];
             NSURLResponse *response = nil;
             NSData *data = [NSURLConnection sendSynchronousRequest:request
                                                  returningResponse:&response
                                                              error:&error];
             html  = [[NSString alloc] initWithData:data
                                                     encoding:NSUTF8StringEncoding];
             
            // NSLog(@"Response is:%@",html);
             
             externaldictionary = [html JSONValue];
             
            // NSLog(@"Response is:%@",externaldictionary);
             
             [detailsArray addObjectsFromArray:[html JSONValue]];
             
            //NSLog(@"detailsArray:%@",detailsArray);
             
                
             /*
              
              Response is:(
              {
              contributors = "<null>";
              coordinates = "<null>";
              "created_at" = "Thu Aug 22 06:25:23 +0000 2013";
              entities =         {
              hashtags =             (
              );
              symbols =             (
              );
              urls =             (
              );
              "user_mentions" =             (
              );
              };
              "favorite_count" = 1;
              favorited = 0;
              geo = "<null>";
              id = 370431485750161408;
              "id_str" = 370431485750161408;
              "in_reply_to_screen_name" = "<null>";
              "in_reply_to_status_id" = "<null>";
              "in_reply_to_status_id_str" = "<null>";
              "in_reply_to_user_id" = "<null>";
              "in_reply_to_user_id_str" = "<null>";
              lang = en;
              place = "<null>";
              "retweet_count" = 0;
              retweeted = 0;
              source = web;
              text = "My God Jesus Christ can turn all your fears into courage and sorrow into joy.";
              truncated = 0;
              user =         {
              "contributors_enabled" = 0;
              "created_at" = "Fri Jul 13 17:50:29 +0000 2012";
              "default_profile" = 0;
              "default_profile_image" = 1;
              description = "";
              entities =             {
              description =                 {
              urls =                     (
              );
              };
              };
              "favourites_count" = 0;
              "follow_request_sent" = 0;
              "followers_count" = 1;
              following = 0;
              "friends_count" = 2;
              "geo_enabled" = 0;
              id = 634744577;
              "id_str" = 634744577;
              "is_translator" = 0;
              lang = en;
              "listed_count" = 0;
              location = "";
              name = "K.Vidhyanand";
              notifications = 0;
              "profile_background_color" = 0099B9;
              "profile_background_image_url" = "http://a0.twimg.com/images/themes/theme4/bg.gif";
              "profile_background_image_url_https" = "https://si0.twimg.com/images/themes/theme4/bg.gif";
              "profile_background_tile" = 0;
              "profile_image_url" = "http://a0.twimg.com/sticky/default_profile_images/default_profile_5_normal.png";
              "profile_image_url_https" = "https://si0.twimg.com/sticky/default_profile_images/default_profile_5_normal.png";
              "profile_link_color" = 0099B9;
              "profile_sidebar_border_color" = 5ED4DC;
              "profile_sidebar_fill_color" = 95E8EC;
              "profile_text_color" = 3C3940;
              "profile_use_background_image" = 1;
              protected = 0;
              "screen_name" = KVidhyanand;
              "statuses_count" = 2;
              "time_zone" = "<null>";
              url = "<null>";
              "utc_offset" = "<null>";
              verified = 0;
              };
              },
              {
              contributors = "<null>";
              coordinates = "<null>";
              "created_at" = "Thu Aug 22 06:24:18 +0000 2013";
              entities =         {
              hashtags =             (
              );
              symbols =             (
              );
              urls =             (
              );
              "user_mentions" =             (
              );
              };
              "favorite_count" = 0;
              favorited = 0;
              geo = "<null>";
              id = 370431216534577152;
              "id_str" = 370431216534577152;
              "in_reply_to_screen_name" = "<null>";
              "in_reply_to_status_id" = "<null>";
              "in_reply_to_status_id_str" = "<null>";
              "in_reply_to_user_id" = "<null>";
              "in_reply_to_user_id_str" = "<null>";
              lang = en;
              place = "<null>";
              "retweet_count" = 0;
              retweeted = 0;
              source = web;
              text = "Jesus Christ is the light of the world.";
              truncated = 0;
              user =         {
              "contributors_enabled" = 0;
              "created_at" = "Fri Jul 13 17:50:29 +0000 2012";
              "default_profile" = 0;
              "default_profile_image" = 1;
              description = "";
              entities =             {
              description =                 {
              urls =                     (
              );
              };
              };
              "favourites_count" = 0;
              "follow_request_sent" = 0;
              "followers_count" = 1;
              following = 0;
              "friends_count" = 2;
              "geo_enabled" = 0;
              id = 634744577;
              "id_str" = 634744577;
              "is_translator" = 0;
              lang = en;
              "listed_count" = 0;
              location = "";
              name = "K.Vidhyanand";
              notifications = 0;
              "profile_background_color" = 0099B9;
              "profile_background_image_url" = "http://a0.twimg.com/images/themes/theme4/bg.gif";
              "profile_background_image_url_https" = "https://si0.twimg.com/images/themes/theme4/bg.gif";
              "profile_background_tile" = 0;
              "profile_image_url" = "http://a0.twimg.com/sticky/default_profile_images/default_profile_5_normal.png";
              "profile_image_url_https" = "https://si0.twimg.com/sticky/default_profile_images/default_profile_5_normal.png";
              "profile_link_color" = 0099B9;
              "profile_sidebar_border_color" = 5ED4DC;
              "profile_sidebar_fill_color" = 95E8EC;
              "profile_text_color" = 3C3940;
              "profile_use_background_image" = 1;
              protected = 0;
              "screen_name" = KVidhyanand;
              "statuses_count" = 2;
              "time_zone" = "<null>";
              url = "<null>";
              "utc_offset" = "<null>";
              verified = 0;
              };
              }
              )


              */
                         
         }
         //NSLog(@"Details Array at parse method:%d",[detailsArray count]);
         [self.detailsTableView reloadData];

     }];
    [self.spinner stopAnimating];
    
}
#pragma mark---Tableview delegate methods

-(NSInteger) numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [detailsArray count];
    
    //NSLog(@"Details Array at no of rows:%d",[detailsArray count]);
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 135;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier=@"cell";
    
    ParseDetailsCell *cell=(ParseDetailsCell *)[detailsTableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell==nil)
    {
        [[NSBundle mainBundle] loadNibNamed:@"ParseDetailsCell" owner:self options:nil];
        cell=self.parseCell;
    }
    
    // Do something with the returned PFObject in the gameScore variable.

    //NSArray *results=[[NSArray alloc] initWithArray:[html JSONValue]];
    
    //NSLog(@"Details Array:%d",[detailsArray count]);
    
    if ([detailsArray count]>0)
    {
        NSDictionary *dic=[detailsArray objectAtIndex:indexPath.row];
        
        NSDictionary *subdic=[dic objectForKey:@"user"];
        
        cell.nameLabel.text=[subdic objectForKey:@"screen_name"];
        
        //NSLog(@"nameDictString is %@",cell.nameLabel.text);//profile_image_url
        
        cell.phonenoLabel.text=[NSString stringWithFormat:@"Followers : %@",[subdic objectForKey:@"followers_count"]];
        
        //NSLog(@"Followers is %@",cell.phonenoLabel.text);
        
        cell.emailLabel.text=[NSString stringWithFormat:@"Following : %@",[subdic objectForKey:@"following"]];
        
        //NSLog(@"Following is %@",cell.emailLabel.text);
        
        cell.dateLabel.text=[dic objectForKey:@"text"];
        
        //NSLog(@"Tweet is:%@",cell.dateLabel.text);
        
        cell.dateLabel.numberOfLines=2;
        
        UIImage *twimage = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[subdic objectForKey:@"profile_image_url"]]]];
        
        cell.profileImage.image =twimage;

    }
   
                

    NSLog(@"First Parse");
    cell.dateLabel.textColor=[UIColor whiteColor];
    cell.nameLabel.textColor=[UIColor whiteColor];
    cell.phonenoLabel.textColor=[UIColor whiteColor];
    cell.emailLabel.textColor=[UIColor whiteColor];
    
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    //cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    
    //NSLog(@"Details Array:%@",detailsArray);
    
    return cell;
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
