//
//  FBFriendsViewController.h
//  ParseSDKSample
//
//  Created by Stellent Software on 8/12/13.
//  Copyright (c) 2013 Stellent Software. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ParseDetailsViewController.h"
#import "AddParseDetailsViewController.h"
#import "FBParseViewController.h"
#import <Parse/Parse.h>

@interface FBFriendsViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

@property(nonatomic,strong)IBOutlet UITableView *contentTableView;

@property(nonatomic,strong)NSMutableArray *contentsArray;

@end
