//
//  ParseObject.h
//  ParseSDKSample
//
//  Created by Stellent Software on 7/25/13.
//  Copyright (c) 2013 Stellent Software. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ParseObject : NSObject

@property(nonatomic,strong)IBOutlet UIImageView *profileImage;
@property(nonatomic,strong)IBOutlet UILabel *nameLabel;
@property(nonatomic,strong)IBOutlet UILabel *phonenoLabel;
@property(nonatomic,strong)IBOutlet UILabel *emailLabel;
@property(nonatomic,strong)IBOutlet UILabel *dateLabel;


@end
