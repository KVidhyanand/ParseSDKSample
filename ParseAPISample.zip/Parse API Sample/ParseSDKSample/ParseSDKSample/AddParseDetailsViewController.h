//
//  AddParseDetailsViewController.h
//  ParseSDKSample
//
//  Created by Stellent Software on 7/25/13.
//  Copyright (c) 2013 Stellent Software. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Parse/Parse.h>
#import "AddParseDetailsViewController.h"
#import <QuartzCore/QuartzCore.h>

@interface AddParseDetailsViewController : UIViewController<UITextFieldDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    UITextField *nameTextField;
    UITextField *phoneNoTextField;
    UITextField *emailIDTextField;
    UIImageView *profileImageView;
    UIButton *saveButton;
    UITextField *currentTextField;
    UIImage *selectedImage;
    PFImageView *image;
    NSMutableArray *profileArray;
    IBOutlet UIButton *deleteButton;
    
}
@property(nonatomic,strong)IBOutlet UIActivityIndicatorView *spinner;
@property(nonatomic,readwrite) int indexSelected;
@property(nonatomic,strong) NSString *comingString;
@property(nonatomic,strong)IBOutlet PFImageView *image;
@property(nonatomic,strong)NSMutableArray *profileArray;
@property(nonatomic,strong)IBOutlet UIImageView *profileImageView;
@property(nonatomic,strong)IBOutlet UITextField *nameTextField;
@property(nonatomic,strong)IBOutlet UITextField *phoneNoTextField;
@property(nonatomic,strong)IBOutlet UITextField *emailIDTextField;
@property(nonatomic,strong)IBOutlet UIButton *saveButton;
@property(nonatomic,strong)IBOutlet UIButton *updateButton;
@property(nonatomic,strong) NSString *delObjId;

@property(nonatomic,strong)PFObject *userInfo ;

-(IBAction)saveButtonAction:(id)sender;
-(IBAction)updateButtonAction:(id)sender;
- (void)retrieveDetails;

@end
