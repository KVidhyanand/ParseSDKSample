//
//  ParseDetailsCell.m
//  ParseSDKSample
//
//  Created by Stellent Software on 7/25/13.
//  Copyright (c) 2013 Stellent Software. All rights reserved.
//

#import "ParseDetailsCell.h"

@implementation ParseDetailsCell

@synthesize dateLabel;
@synthesize nameLabel;
@synthesize profileImage;
@synthesize phonenoLabel;
@synthesize emailLabel;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
