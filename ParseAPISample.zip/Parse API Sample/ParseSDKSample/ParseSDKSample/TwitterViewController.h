//
//  TwitterViewController.h
//  ParseSDKSample
//
//  Created by Stellent Software on 8/23/13.
//  Copyright (c) 2013 Stellent Software. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Parse/Parse.h>
#import "ASIFormDataRequest.h"
#import "ASIHTTPRequest.h"
#import "Reachability.h"
#import "JSON.h"
#import "ParseDetailsCell.h"

@interface TwitterViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

{
    NSString *html;
    
    NSDictionary *externaldictionary;
}

@property(nonatomic,strong)IBOutlet UIActivityIndicatorView *spinner;
@property(nonatomic,strong)IBOutlet UITableView *detailsTableView;
@property(nonatomic,strong)NSMutableArray *detailsArray;
@property(nonatomic,strong)IBOutlet ParseDetailsCell *parseCell;

@end
